import pandas as pd
import joblib
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load the new dataset
new_data_path = (r'/Users/omarkamel/Downloads/data.csv')  # Update with your file path
new_df = pd.read_csv(new_data_path)

#  Drop unnecessary columns
new_df.drop(columns=['id', 'Unnamed: 32'], inplace=True, errors='ignore')

#  Verify column names same features of training model
training_columns = [
    'diagnosis', 'radius_mean', 'texture_mean', 'perimeter_mean', 'area_mean', 'smoothness_mean',
    'compactness_mean', 'concavity_mean', 'concave points_mean', 'symmetry_mean', 'fractal_dimension_mean',
    'radius_se', 'texture_se', 'perimeter_se', 'area_se', 'smoothness_se', 'compactness_se', 'concavity_se',
    'concave points_se', 'symmetry_se', 'fractal_dimension_se', 'radius_worst', 'texture_worst', 'perimeter_worst',
    'area_worst', 'smoothness_worst', 'compactness_worst', 'concavity_worst', 'concave points_worst', 'symmetry_worst',
    'fractal_dimension_worst'
]

if set(new_df.columns) == set(training_columns):
    print(" Column names match the training dataset.")
else:
    print("⚠ Column names do not match the training dataset.")
    print("Columns in new dataset:", new_df.columns)
    print("Columns in training dataset:", training_columns)

# : Check for missing values
print("\nMissing values in the new dataset after dropping unnecessary columns:")
print(new_df.isnull().sum())

#  Encode the target variable
if "diagnosis" in new_df.columns:
    new_df["diagnosis"] = new_df["diagnosis"].apply(lambda x: 1 if x == "M" else 0)

# Display the preprocessed dataset
print("\nPreprocessed dataset:")
print(new_df.head())

#  Load the scaler and scale the features from the training
scaler = joblib.load('/Users/omarkamel/Downloads/scaler.pkl')

# Ensure the new dataset has the same columns as the training dataset
# Reorder columns to match the training dataset
new_df_aligned = new_df[scaler.feature_names_in_]

# Scale the features and convert back to DataFrame
X_new_scaled = scaler.transform(new_df_aligned)
X_new_scaled_df = pd.DataFrame(X_new_scaled, columns=scaler.feature_names_in_)

#  Load the feature selector and select the same features used during training (RFE) / select the top features
feature_selector = joblib.load('/Users/omarkamel/Downloads/feature_selector.pkl')

#  Convert DataFrame to NumPy array to avoid warnings
X_new_selected = feature_selector.transform(X_new_scaled_df.to_numpy())

#  Load the trained logeistic model
model = joblib.load('/Users/omarkamel/Downloads/breast_cancer_model.pkl')

#  Make predictions
predictions = model.predict(X_new_selected)

#  Display predictions
print("Predictions on the new dataset:", predictions)

#  Evaluate the model (if true labels are available)
if "diagnosis" in new_df.columns:
    y_true = new_df["diagnosis"].values  # True labels from the new dataset

    # Accuracy
    accuracy = accuracy_score(y_true, predictions)
    print(f"\n Accuracy on the new dataset: {accuracy:.4f}")

    # Classification Report
    print("\nClassification Report:\n", classification_report(y_true, predictions))

    # Confusion Matrix
    conf_matrix = confusion_matrix(y_true, predictions)
    print("\nConfusion Matrix:\n", conf_matrix)
else:
    print(" No true labels ('diagnosis' column) found in the new dataset for evaluation.")

# Compare predictions to true labels (Additional Step)
for i in range(len(predictions)):
    print(f"Sample {i}: Predicted = {predictions[i]}, Actual = {y_true[i]}")
